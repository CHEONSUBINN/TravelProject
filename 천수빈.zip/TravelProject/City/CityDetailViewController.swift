//
//  CityDetailViewController.swift
//  TravelProject
//
//  Created by subin on 7/17/25.
//

import UIKit
import Kingfisher

class CityDetailViewController: UIViewController {
    
    var cityContent: City = City(city_name: "", city_english_name: "", city_explain: "", city_image: "", domestic_travel: false)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        
    }
    

}
