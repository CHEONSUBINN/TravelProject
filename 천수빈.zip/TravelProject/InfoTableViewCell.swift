//
//  InfoTableViewCell.swift
//  TravelProject
//
//  Created by subin on 7/15/25.
//

import UIKit

class InfoTableViewCell: UITableViewCell {

    @IBOutlet var infoImage: UIImageView!
    @IBOutlet var infoTitleLabel: UILabel!
    @IBOutlet var infoSubTitle: UILabel!
    @IBOutlet var reviewLabel: UILabel!
    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//    
//    }

}
